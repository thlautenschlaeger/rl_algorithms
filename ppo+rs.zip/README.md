# Group ID 1 

Implementation of PPO and RS

## Dirty versions of both algorithms runs on qube environment 
