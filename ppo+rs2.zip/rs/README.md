# Random Search

## run rs
go to quanser_platforms -> qube.py and execute run_rs()
to execute rs

  