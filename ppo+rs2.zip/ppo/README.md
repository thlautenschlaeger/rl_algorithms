# Proximal Policy Optimization

## run ppo
go to quanser_platforms -> qube.py 
and execute run_ppo()